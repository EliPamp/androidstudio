package com.example.p03_intentexplicite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class EmployeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employe);
        Intent intent = getIntent();
        String msg = intent.getExtras().getString("message");
        TextView tv = findViewById(R.id.idMessage);
        tv.setText(msg);
    }
    public void btnOkOnClick(View source){

    }
    public void btnAnnulerOnClick(View source){
        finish();
    }
}
